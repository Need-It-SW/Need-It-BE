package com.needitbe.domain.campaign.dto;

import com.needitbe.domain.campaign.entity.AdType;
import jakarta.validation.constraints.*;

import java.time.LocalDate;

public record AdCampaignCreateRequest(

        @NotBlank(message = "캠페인 이름은 필수입니다.")
        @Size(max = 100)
        String name,

        @NotNull(message = "광고 노출 방식은 필수입니다.")
        AdType adType,

        // 타깃 카테고리
        String targetCategory,

        // 수집 행동 유형
        String targetAction,

        // 타깃 키워드 (쉼표 구분)
        String targetKeywords,

        // 대상 지역 (쉼표 구분)
        String targetRegions,

        // 사용자별 최대 노출 횟수
        @Min(value = 1, message = "최대 노출 횟수는 1 이상이어야 합니다.")
        int maxImpressions,

        // 노출 횟수 집계 기간
        @NotBlank(message = "노출 횟수 집계 기간은 필수입니다.")
        @Pattern(
                regexp = "TOTAL|ALL|DAILY|WEEKLY|LAST_24_HOURS|LAST_7_DAYS",
                message = "지원하지 않는 노출 집계 기간입니다."
        )
        String impressionPeriod,

        @NotNull(message = "시작일은 필수입니다.")
        LocalDate startDate,

        @NotNull(message = "종료일은 필수입니다.")
        LocalDate endDate,

        // 캠페인 설명
        String description,

        // 캠페인 활성화 여부
        boolean active

) {
    // 종료일이 시작일보다 빠른 경우 방지
    @AssertTrue(message = "종료일은 시작일보다 빠를 수 없습니다.")
    public boolean isValidDateRange() {
        if (startDate == null || endDate == null) {
            return true;
        }

        return !endDate.isBefore(startDate);
    }
}