package com.needitbe.domain.member.entity;

import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Table(
        name = "members",
        uniqueConstraints = {
                @UniqueConstraint(
                        name = "uk_members_username",
                        columnNames = "username"
                ),
                @UniqueConstraint(
                        name = "uk_members_nickname",
                        columnNames = "nickname"
                )
        }
)
public class Member {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 32)
    private String username;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false, length = 20)
    private String nickname;

    @Column(nullable = false, length = 100)
    private String region;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private MemberRole role;

    @Column(name = "profile_image_key", length = 500)
    private String profileImageKey;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private MemberStatus status = MemberStatus.ACTIVE;


    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }

    public Member(
            String username,
            String password,
            String nickname,
            String region
    ) {
        this.username = username;
        this.password = password;
        this.nickname = nickname;
        this.region = region;
        this.role = MemberRole.USER;
        this.status = MemberStatus.ACTIVE;
    }
    // 아이디 변경
    public void updateUsername(String username) {
        this.username = username;
    }
    // 프로필 사진 변경
    public void updateProfileImage(String profileImageKey) {
        this.profileImageKey = profileImageKey;
    }

    // 프로필 사진 삭제
    public void deleteProfileImage() {
        this.profileImageKey = null;
    }

    // 닉네임 변경
    public void updateNickname(String nickname) {
        this.nickname = nickname;
    }

    // 활동 동네 변경
    public void updateRegion(String region) {
        this.region = region;
    }
    // 비밀번호 변경
    public void updatePassword(String encodedPassword) {
        this.password = encodedPassword;
    }

    // 회원 이용 정지
    public void suspend() {
        this.status = MemberStatus.SUSPENDED;
    }

    // 회원 이용 정지 해제
    public void activate() {
        this.status = MemberStatus.ACTIVE;
    }
}